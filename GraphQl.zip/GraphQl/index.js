import express from 'express'
import resolvers from './resolvers'
import schema from './schema'
import { graphqlHTTP } from "express-graphql";


const app=express()
const port=3000

app.get("/",(req,res)=>{
    res.send("server running")
})

const root=resolvers;

app.use('/graphql', graphqlHTTP({
    schema:schema,
    rootValue:root,
    graphiql:true
}))

app.listen(port,()=>console.log(`running at port ${port}`))