import { buildSchema } from "graphql";

const schema = buildSchema(`
    type Course{
        id: ID
        courseName: String
        caegory: String
        price: Float
        email:String
        stack:Stack
        teachingAssists: [TeachingAssists]
    }
    type TeachingAssists{
        firstName: String
        lastName: String
        experience : Int
    }

    enum Stack{
        WEB
        MOBILE
        OTHER
    }

    type Query{
        getCourse(id: ID): Course
    }

    input CourseInput{
        id: ID
        courseName: String!
        caegory: String
        price: Float!
        email:String
        stack:Stack
        teachingAssists: [TeachingAssistsInput]!
    }

    input TeachingAssistsInput{
        firstName: String!
        lastName: String!
        experience : Int!
    }

    type Mutation{
        createCourse(input: CourseInput): Course
    }

`)

export default schema;